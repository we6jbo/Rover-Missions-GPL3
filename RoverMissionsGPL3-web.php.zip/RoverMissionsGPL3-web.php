<html>
<meta http-equiv="cache-control" content="max-age=0">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="expires" content="-1">
<meta http-equiv="expires" content="Tue, 01 Jan 1980 11:00:00 GMT">
<meta http-equiv="pragma" content="no-cache">
<body>


<?php
//Get the file

$content = file_get_contents("http://we6jbobbsdotorg.duckdns.org/RoverMissionsGPL3-pi/camera/index.php");

//Store in the filesystem.
$fp = fopen("image1.jpg", "w");
fwrite($fp, $content);
fclose($fp);
echo '<img src="image1.jpg?rnd=' . microtime() . '" width = 1280 height = 720 alt="Image">';


if (isset($_GET['goingforward'])) {
file_get_contents("http://we6jbobbsdotorg.duckdns.org/RoverMissionsGPL3-pi/gpio/goforwards.php");
}
if (isset($_GET['goingbackwards'])) {
file_get_contents("http://we6jbobbsdotorg.duckdns.org/RoverMissionsGPL3-pi/gpio/gobackwards.php");
}
?>
<br>
<br>
<button onclick="goingForward()">Forward</button>
<button onclick="goingBack()">Back</button>


<script type="text/javascript">
function goingForward() {
    location.href='RoverMissionsGPL3-web.php?goingforward=1'
}
function goingBack() {
    location.href='RoverMissionsGPL3-web.php?goingbackwards=1'
}
</script>

</html>
</body>
