<html>
<body>
<?php
system("gpio -g mode 3 out");
system("gpio -g mode 17 out");

system("gpio -g write 3 0");
system("gpio -g write 17 0");

sleep(1);
system("gpio -g write 3 1");
system("gpio -g write 17 1");
echo "Done.";
?>
</body>
</html>
