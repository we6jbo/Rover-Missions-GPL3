<html>
<body>
<?php
system("gpio -g mode 2 out");
system("gpio -g mode 4 out");

system("gpio -g write 2 0");
system("gpio -g write 4 0");

sleep(1);
system("gpio -g write 2 1");
system("gpio -g write 4 1");
echo "Done.";
?>
</body>
</html>
