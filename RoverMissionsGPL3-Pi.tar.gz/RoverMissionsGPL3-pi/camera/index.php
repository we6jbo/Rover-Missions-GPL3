<?php
//get the last used number for naming file

shell_exec("raspistill -w 300 -h 300 -t 1000 -o /var/www/novnc/camera/img/photo.jpg");

header("Content-type: image/jpeg");
$im = imagecreatefromjpeg("/var/www/novnc/RoverMissionsGPL3-pi/camera/img/photo.jpg");
imagejpeg($im);
imagedestroy($im);

exit(0);
?>
