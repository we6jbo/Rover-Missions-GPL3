﻿namespace RoverMissionsGPL3
{
    partial class RoverMissionsGPL3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RoverMissionsGPL3_web = new System.Windows.Forms.WebBrowser();
            this.SuspendLayout();
            // 
            // RoverMissionsGPL3_web
            // 
            this.RoverMissionsGPL3_web.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RoverMissionsGPL3_web.Location = new System.Drawing.Point(0, 0);
            this.RoverMissionsGPL3_web.MinimumSize = new System.Drawing.Size(20, 20);
            this.RoverMissionsGPL3_web.Name = "RoverMissionsGPL3_web";
            this.RoverMissionsGPL3_web.Size = new System.Drawing.Size(1325, 795);
            this.RoverMissionsGPL3_web.TabIndex = 0;
            this.RoverMissionsGPL3_web.Url = new System.Uri("http://jeremiahonealts.com/RoverMissionsGPL3-web.php", System.UriKind.Absolute);
            // 
            // RoverMissionsGPL3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1325, 795);
            this.Controls.Add(this.RoverMissionsGPL3_web);
            this.Name = "RoverMissionsGPL3";
            this.Text = "Rover Missions GPL3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser RoverMissionsGPL3_web;
    }
}

